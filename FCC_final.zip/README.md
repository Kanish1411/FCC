####
pip install -r req.txt
 
to install alla the packages required for this code to run

if some package causes error update your pip


###

My python version as of V1.0 of this code is Python 3.10.13

